package com.aartek.prestigepoint.model;

import java.io.FileNotFoundException;
import java.io.RandomAccessFile;

public class sample {

	public static void main(String[] args) {
		/*
		 * try { RandomAccessFile raf = new RandomAccessFile("asd.txt", "r"); byte b[] =
		 * new byte[1000]; raf.readFully(b, 0, 1000); } catch (FileNotFoundException ex)
		 * { ex.printStackTrace(); }
		 */}
}