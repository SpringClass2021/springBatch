/*package com.aartek.prestigepoint.repository;

import com.aartek.prestigepoint.model.UploadBanner;

public interface UploadBannerRepository {
	public void uploadBImage(UploadBanner uploadBanner);
	
}
*/