/*package com.aartek.prestigepoint.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
//import javax.persistence.JoinColumn;
//import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "bannerImage")
public class UploadBanner implements Serializable {

  private static final long serialVersionUID = 1L;
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name = "IMAGE_ID")
  private Integer image_Id;

  @Column(name = "IMAGE_TYPE")
  private String imageType;

  @Column(name = "NAME_OF_IMAGE")
  private String nameOfImage;

  @Column(name = "PATH_OF_IMAGE")
  private String pathOfImage;

public Integer getImage_Id() {
	return image_Id;
}

public void setImage_Id(Integer image_Id) {
	this.image_Id = image_Id;
}

public String getImageType() {
	return imageType;
}

public void setImageType(String imageType) {
	this.imageType = imageType;
}

public String getNameOfImage() {
	return nameOfImage;
}

public void setNameOfImage(String nameOfImage) {
	this.nameOfImage = nameOfImage;
}

public String getPathOfImage() {
	return pathOfImage;
}

public void setPathOfImage(String pathOfImage) {
	this.pathOfImage = pathOfImage;
}

  
}
*/