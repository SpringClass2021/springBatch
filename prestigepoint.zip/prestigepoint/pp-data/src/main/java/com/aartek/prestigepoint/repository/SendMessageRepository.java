package com.aartek.prestigepoint.repository;


public interface SendMessageRepository {

}