$(document).ready(function() {
	/*$('#banner').fullBanner();*/
	$('.col-point > ul > li').accordion();
});