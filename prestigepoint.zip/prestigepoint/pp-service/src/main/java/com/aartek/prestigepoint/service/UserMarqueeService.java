package com.aartek.prestigepoint.service;

import java.util.List;

import com.aartek.prestigepoint.model.AddMarquee;

public interface UserMarqueeService {

public List<AddMarquee> fatchMarqueeDescription();

}
