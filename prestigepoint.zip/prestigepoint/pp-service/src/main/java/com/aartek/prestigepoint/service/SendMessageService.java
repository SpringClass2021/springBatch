package com.aartek.prestigepoint.service;

import java.util.List;

import com.aartek.prestigepoint.model.Batch;

public interface SendMessageService {

	

	
	List<Batch> getAllStudentList(Batch batch);

}
