/*package com.aartek.prestigepoint.service;

import com.aartek.prestigepoint.model.UploadBanner;

public interface UploadBannerService {

	public void uploadBImage(UploadBanner uploadBanner);

	
	
}
*/