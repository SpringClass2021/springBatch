package com.aartek.prestigepoint.service;

public interface ForgotPasswordAdminService {

	public boolean getPassword(String emailId);

}
